"""Snap Translation Status — check l10n status of installed snaps."""
__version__ = "0.1.0"
